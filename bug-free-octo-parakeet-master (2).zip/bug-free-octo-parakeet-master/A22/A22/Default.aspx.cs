﻿using System;
using System.Web;
using System.Web.UI;


namespace A22
{

    public partial class Default : System.Web.UI.Page
    {
       
        protected void submit_Click(object sender, EventArgs e)
        {


        }


    }


}
